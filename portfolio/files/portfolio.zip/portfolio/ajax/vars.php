<?php
$USERNAME="bsr618";
$PASSWORD="zf8pO0pRn";