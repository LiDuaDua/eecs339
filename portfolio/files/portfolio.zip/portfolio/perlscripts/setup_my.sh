export PORTF_DBMS='mysql'
export PORTF_DB='cs339data'
export PORTF_DBUSER='cs339'
export PORTF_DBPASS='cs339'

