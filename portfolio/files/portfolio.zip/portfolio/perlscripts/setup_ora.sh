export PORTF_DBMS='oracle'
export PORTF_DB='cs339'
export PORTF_DBUSER='pdinda'
export PORTF_DBPASS='pdinda'
